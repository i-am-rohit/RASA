## intent:affirm
- yes
- indeed
- of course
- that sounds good
- correct

## intent:age
- 24

## intent:bot_challenge
- are you a bot?
- are you a human?
- am I talking to a bot?
- am I talking to a human?

## intent:choose
- /choose[{"G": "Graduate"}](G:Graduate)
- /choose[{"Apple": "Apple"}](Apple:Apple)
- /choose[{"Dog": "Dog"}](Dog:Dog)
- /choose[{"Basketball": "Basketball"}](Basketball:Basketball)
- /choose[{"Horn prohibited": "Horn prohibited"}](Horn prohibited:Horn prohibited)
- /choose[{"Hospital": "Hospital"}](Hospital:Hospital)

## intent:deny
- no
- never
- I don't think so
- don't like that
- no way
- not really

## intent:goodbye
- bye
- goodbye
- see you around
- see you later

## intent:greet
- hey
- hello
- hi
- good morning
- good evening
- hey there

## intent:mood_great
- perfect
- very good
- great
- amazing
- wonderful
- I am feeling very good
- I am great
- I'm good

## intent:mood_unhappy
- sad
- very sad
- unhappy
- bad
- very bad
- awful
- terrible
- not very good
- extremely sad
- so sad

## intent:name
- Rohit

## synonym:Apple
- {"Apple": "Apple"}

## synonym:Basketball
- {"Basketball": "Basketball"}

## synonym:Dog
- {"Dog": "Dog"}

## synonym:Graduate
- {"G": "Graduate"}

## synonym:Horn prohibited
- {"Horn prohibited": "Horn prohibited"}

## synonym:Hospital
- {"Hospital": "Hospital"}
