## happy path
* greet
  - utter_greet
* mood_great
  - utter_happy

## sad path 1
* greet
  - utter_greet
* mood_unhappy
  - utter_cheer_up
  - utter_did_that_help
* affirm
  - utter_happy

## sad path 2
* greet
  - utter_greet
* mood_unhappy
  - utter_cheer_up
  - utter_did_that_help
* deny
  - utter_goodbye

## say greet
* greet
  - utter_greet

## bot challenge
* bot_challenge
  - utter_iamabot

## New Story

* greet
    - utter_ask_name
* greet
    - utter_ask_age
* age
    - utter_ask_qualification
* choose{"G":"Graduate"}
    - utter_ask_fruit
* choose{"Apple":"Apple"}
    - utter_ask_animal
* choose{"Dog":"Dog"}
    - utter_ask_game
* choose{"Basketball":"Basketball"}
    - utter_ask_sign
* choose{"Horn prohibited":"Horn prohibited"}
    - utter_ask_place
* choose{"Hospital":"Hospital"}
    - utter_thanx
    - utter_goodbye

## New Story

* hi
    - utter_ask_name
* Rohit
    - utter_ask_age
* 24
    - utter_ask_qualification
* choose{"G":"Graduate"}
    - utter_ask_fruit
* choose{"Apple":"Apple"}
    - utter_ask_animal
* choose{"Dog":"Dog"}
    - utter_ask_game
* choose{"Basketball":"Basketball"}
    - utter_ask_sign
* choose{"Horn prohibited":"Horn prohibited"}
    - utter_ask_place
* choose{"Hospital":"Hospital"}
    - utter_thanx
    - utter_goodbye
